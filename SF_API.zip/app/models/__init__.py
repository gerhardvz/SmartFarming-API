# from .Devices import Device
# from .ML_Reading import MlReading
# from .Prediction_Enum import PredictionEnum
# from .Reading import Reading

# def init_app(app):



